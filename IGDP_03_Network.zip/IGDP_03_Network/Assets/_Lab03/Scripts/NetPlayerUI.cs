using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Mirror;
using UnityEngine.UI;

public class NetPlayerUI : MonoBehaviour
{
    [Header("Player Components")]
    public Image image;

    [Header("Player Components")]
    public Text playerNameText;
    public Text playerDataText;

    // sets a highlight color for the local player
    public void SetLocalPlayer()
    {
        // add a visual background for the local player in the UI
        image.color = new Color(1f, 1f, 1f, 0.1f);
    }

    // this value can change as clients leave and join
    public void OnPlayerNumberChanged(byte newPlayerNumber)
    {
        playerNameText.text = string.Format("Player {0:00}", newPlayerNumber);
    }

    // random color set by Player::OnStartServer
    public void OnPlayerColorChanged(Color32 newPlayerColor)
    {
        playerNameText.color = newPlayerColor;
    }

    // this updaes from Player::UpdateData via InvokeRepeating on Server
    public void OnPlayerDataChanged(ushort newPlayerData)
    {
        // show the data in the UI
        playerDataText.text = string.Format("Data: {0:000}", newPlayerData);
    }

}
