using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Mirror;

[AddComponentMenu("Network Manager")]
public class NetManager : NetworkManager
{
    public static new NetManager singleton { get; private set; }

    
    // runs on both server and client.
    // networking is not initialized when this fires
    public override void Awake()
    {
        base.Awake();
        singleton = this;
    }

    // Called on the server when a client adds a new player with NetworkClient.AddPlayer.
    // The default implementation for this function creates a new player boject from the playerPrefa.
    // <param name="conn">Connection from the client.</param>
    public override void OnServerAddPlayer(NetworkConnectionToClient conn)
    {
        base.OnServerAddPlayer(conn);
        // Player.ResetPlayerNumbers();
    }

    // called on the server when a client disconnects
    // This is called on the server when a Client disconnects from ther server.
    public override void OnServerDisconnect(NetworkConnectionToClient conn)
    {
        base.OnServerDisconnect(conn);
        // Player.ResetPlayerNumbers();
    }



}
