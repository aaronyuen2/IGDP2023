namespace kcp2k
{
    internal struct AckItem
    {
        internal uint serialNumber;
        internal uint timestamp;
    }
}
